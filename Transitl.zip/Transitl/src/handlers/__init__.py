from aiogram import Dispatcher

from src.handlers.start import router as start_router
from src.handlers.registration import router as registration_router
from src.handlers.orders import router as orders_router
from src.handlers.documents import router as documents_router


def register_all_handlers(dp: Dispatcher):
    dp.include_router(start_router)
    dp.include_router(registration_router)
    dp.include_router(orders_router)
    dp.include_router(documents_router)
